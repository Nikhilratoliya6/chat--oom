# Process Mining - Final assignement

Final project for the Process Mining part of the Service and Micro-service course for M2 SIGLIS and Industry 4.0 at UPPA.
For this assignement, we chose to work on the hospital dataset (available in the dataset folder!)

## Testing on Kaggle.

I've made all 4 scripts available for free on Kaggle for you to test them directly. The dataset is already included for all 4 dataset. 
[Found my stuff on Kaggle](https://www.kaggle.com/clmentcombier)
